package com.gajetino.app

import android.Manifest
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalLayoutDirection
import coil.compose.AsyncImage
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.messaging.FirebaseMessaging
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL
import java.text.DecimalFormat
import java.util.Locale

private val Navy = Color(0xFF07152F)
private val Blue = Color(0xFF1769E8)
private val Cyan = Color(0xFF13C7D9)
private val Ink = Color(0xFF14213D)
private val Muted = Color(0xFF78849B)
private val Surface = Color(0xFFFFFFFF)
private val Canvas = Color(0xFFF5F7FB)
private const val SITE = "https://www.gajetino.com"
private const val API = "$SITE/wp-json/wc/store/v1"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                GajetinoApp()
            }
        }
    }
}

data class StoreProduct(
    val id: Int,
    val name: String,
    val price: String,
    val regularPrice: String,
    val image: String,
    val url: String,
    val categories: List<String>
)

data class StoreCategory(val id: Int, val name: String)
data class OrderInfo(val number: String, val status: String, val total: String, val date: String, val items: List<String>, val tracking: String)

private object StoreApi {
    suspend fun products(search: String = "", category: Int? = null): List<StoreProduct> = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        val params = mutableListOf("per_page=24", "orderby=popularity")
        if (search.isNotBlank()) params += "search=${enc(search)}"
        if (category != null) params += "category=$category"
        val json = JSONArray(request("$API/products?${params.joinToString("&")}"))
        buildList {
            for (i in 0 until json.length()) {
                val p = json.getJSONObject(i)
                val prices = p.optJSONObject("prices") ?: JSONObject()
                val imgs = p.optJSONArray("images") ?: JSONArray()
                val image = if (imgs.length() > 0) imgs.optJSONObject(0)?.optString("src", "") ?: "" else ""
                val cats = p.optJSONArray("categories") ?: JSONArray()
                val names = buildList { for (j in 0 until cats.length()) add(cats.optJSONObject(j)?.optString("name", "") ?: "") }
                add(StoreProduct(
                    id = p.optInt("id"),
                    name = p.optString("name", "محصول گجتینو"),
                    price = prices.optString("price", ""),
                    regularPrice = prices.optString("regular_price", ""),
                    image = image,
                    url = p.optString("permalink", SITE),
                    categories = names
                ))
            }
        }
    }

    suspend fun productsByIds(ids: Set<Int>): List<StoreProduct> = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        if (ids.isEmpty()) return@withContext emptyList()
        val json = JSONArray(request("$API/products?include=${ids.joinToString(",")}&per_page=100"))
        buildList {
            for (i in 0 until json.length()) {
                val p = json.getJSONObject(i)
                val prices = p.optJSONObject("prices") ?: JSONObject()
                val imgs = p.optJSONArray("images") ?: JSONArray()
                val image = if (imgs.length() > 0) imgs.optJSONObject(0)?.optString("src", "") ?: "" else ""
                val cats = p.optJSONArray("categories") ?: JSONArray()
                val names = buildList { for (j in 0 until cats.length()) add(cats.optJSONObject(j)?.optString("name", "") ?: "") }
                add(StoreProduct(p.optInt("id"), p.optString("name", "محصول گجتینو"), prices.optString("price", ""), prices.optString("regular_price", ""), image, p.optString("permalink", SITE), names))
            }
        }
    }

    suspend fun categories(): List<StoreCategory> = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        val json = JSONArray(request("$API/products/categories?per_page=50&hide_empty=true"))
        buildList { for (i in 0 until json.length()) { val c = json.getJSONObject(i); add(StoreCategory(c.optInt("id"), c.optString("name"))) } }
    }

    suspend fun trackOrder(orderNumber: String, email: String): OrderInfo = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        val body = JSONObject().put("order_number", orderNumber).put("billing_email", email)
        val response = request("$SITE/wp-json/gajetino/v1/track-order", "POST", body.toString())
        val obj = JSONObject(response)
        val arr = obj.optJSONArray("items") ?: JSONArray()
        val items = buildList { for (i in 0 until arr.length()) add(arr.optString(i)) }
        OrderInfo(
            number = obj.optString("number", orderNumber),
            status = obj.optString("status_label", obj.optString("status", "در حال بررسی")),
            total = obj.optString("total", ""),
            date = obj.optString("date", ""),
            items = items,
            tracking = obj.optString("tracking", "")
        )
    }

    private fun request(url: String, method: String = "GET", body: String? = null): String {
        val connection = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = method
            connectTimeout = 15000
            readTimeout = 20000
            setRequestProperty("Accept", "application/json")
            if (body != null) {
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
                outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
        }
        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
        connection.disconnect()
        if (code !in 200..299) {
            val message = try { JSONObject(text).optString("message", "خطا در دریافت اطلاعات") } catch (_: Exception) { "خطای ارتباط با سرور ($code)" }
            throw IllegalStateException(message)
        }
        return text
    }
    private fun enc(value: String) = URLEncoder.encode(value, "UTF-8")
}

@Composable
private fun GajetinoApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var splash by remember { mutableStateOf(true) }
    var tab by remember { mutableStateOf(0) }
    var products by remember { mutableStateOf<List<StoreProduct>>(emptyList()) }
    var favoriteProducts by remember { mutableStateOf<List<StoreProduct>>(emptyList()) }
    var categories by remember { mutableStateOf<List<StoreCategory>>(emptyList()) }
    var favorites by remember { mutableStateOf(loadFavorites(context)) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf<Int?>(null) }
    var query by remember { mutableStateOf("") }
    var pushEnabled by remember { mutableStateOf(context.getSharedPreferences("gajetino", Context.MODE_PRIVATE).getBoolean("push", false)) }
    var pushMessage by remember { mutableStateOf("") }

    suspend fun refresh(search: String = query, category: Int? = selectedCategory) {
        loading = true
        error = ""
        try {
            products = StoreApi.products(search, category)
            error = ""
        } catch (e: Exception) {
            error = e.message ?: "ارتباط با فروشگاه برقرار نشد"
        } finally { loading = false }
    }

    LaunchedEffect(tab, favorites) {
        if (tab == 1 && favorites.isNotEmpty()) { try { favoriteProducts = StoreApi.productsByIds(favorites) } catch (_: Exception) { } }
    }

    LaunchedEffect(Unit) {
        delay(1100)
        splash = false
        try { categories = StoreApi.categories() } catch (_: Exception) { }
        refresh("", null)
    }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted || Build.VERSION.SDK_INT < 33) {
            enablePromotions(context) { msg -> pushMessage = msg; if (msg.startsWith("فعال شد")) pushEnabled = true }
        } else pushMessage = "برای دریافت اعلان‌ها، مجوز اعلان را از تنظیمات گوشی فعال کن."
    }

    MaterialTheme(
        colorScheme = lightColorScheme(primary = Blue, secondary = Cyan, background = Canvas, surface = Surface, onSurface = Ink)
    ) {
        if (splash) {
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Navy, Color(0xFF102E65)))), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    AsyncImage(model = R.drawable.gajetino_logo, contentDescription = "لوگوی گجتینو", modifier = Modifier.size(180.dp).clip(RoundedCornerShape(34.dp)))
                    Text("گجتینو", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Black)
                    Text("دنیای گجت‌ها، نزدیک‌تر از همیشه", color = Color(0xFFB7D7FF), fontSize = 13.sp)
                }
            }
        } else {
            Scaffold(
                containerColor = Canvas,
                bottomBar = {
                    NavigationBar(containerColor = Surface, tonalElevation = 8.dp) {
                        NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("خانه") })
                        NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Icon(Icons.Default.Favorite, null) }, label = { Text("علاقه‌مندی") })
                        NavigationBarItem(selected = tab == 2, onClick = { tab = 2 }, icon = { Icon(Icons.Default.LocalShipping, null) }, label = { Text("پیگیری سفارش") })
                        NavigationBarItem(selected = tab == 3, onClick = { tab = 3 }, icon = { Icon(Icons.Default.Person, null) }, label = { Text("حساب من") })
                    }
                }
            ) { padding ->
                when (tab) {
                    0 -> HomeScreen(
                        Modifier.padding(padding), products, categories, loading, error, query, selectedCategory,
                        onQueryChange = { query = it },
                        onSearch = { scope.launch { refresh(query, selectedCategory) } },
                        onCategory = { selectedCategory = it; scope.launch { refresh(query, it) } },
                        favorites = favorites,
                        onFavorite = { id -> favorites = toggleFavorite(context, favorites, id) },
                        onOpenProduct = { openUrl(context, it) },
                        onRetry = { scope.launch { refresh(query, selectedCategory) } },
                        pushEnabled = pushEnabled,
                        onEnablePush = {
                            if (Build.VERSION.SDK_INT >= 33) permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                            else { enablePromotions(context) { msg -> pushMessage = msg; if (msg.startsWith("فعال شد")) pushEnabled = true } }
                        }
                    )
                    1 -> FavoritesScreen(Modifier.padding(padding), favoriteProducts, favorites, onFavorite = { id -> favorites = toggleFavorite(context, favorites, id) }, onOpen = { openUrl(context, it) })
                    2 -> TrackingScreen(Modifier.padding(padding))
                    else -> AccountScreen(Modifier.padding(padding), pushEnabled, pushMessage, onEnablePush = {
                        if (Build.VERSION.SDK_INT >= 33) permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        else { enablePromotions(context) { msg -> pushMessage = msg; if (msg.startsWith("فعال شد")) pushEnabled = true } }
                    }, onDisablePush = { pushMessage = disablePromotions(context); pushEnabled = false }, onOpenSite = { openUrl(context, SITE) })
                }
            }
        }
    }
}

@Composable
private fun HomeScreen(
    modifier: Modifier, products: List<StoreProduct>, categories: List<StoreCategory>, loading: Boolean, error: String,
    query: String, selectedCategory: Int?, onQueryChange: (String) -> Unit, onSearch: () -> Unit,
    onCategory: (Int?) -> Unit, favorites: Set<Int>, onFavorite: (Int) -> Unit,
    onOpenProduct: (String) -> Unit, onRetry: () -> Unit, pushEnabled: Boolean, onEnablePush: () -> Unit
) {
    LazyColumn(modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Column(Modifier.fillMaxWidth().background(Navy).padding(horizontal = 18.dp, vertical = 18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("سلام، به گجتینو خوش اومدی", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Text("خرید هوشمندانه‌ی لوازم دیجیتال", color = Color(0xFFB9D6FF), fontSize = 12.sp)
                    }
                    Box(Modifier.size(46.dp).clip(CircleShape).background(Color.White.copy(alpha = .12f)), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Bolt, null, tint = Cyan, modifier = Modifier.size(28.dp))
                    }
                }
                Spacer(Modifier.height(16.dp))
                OutlinedTextField(
                    value = query, onValueChange = onQueryChange, modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("جست‌وجوی محصول، برند یا دسته‌بندی...", fontSize = 12.sp) },
                    leadingIcon = { Icon(Icons.Default.Search, null) }, trailingIcon = { IconButton(onClick = onSearch) { Icon(Icons.Default.ArrowForward, "جست‌وجو") } },
                    singleLine = true, shape = RoundedCornerShape(16.dp), colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = Color.White, unfocusedContainerColor = Color.White,
                        focusedBorderColor = Cyan, unfocusedBorderColor = Color.White
                    )
                )
            }
        }
        item {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp).clip(RoundedCornerShape(20.dp)).background(Brush.horizontalGradient(listOf(Color(0xFF0C4BA6), Color(0xFF13B8D0)))).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("تجربه خرید مطمئن", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Text("محصولات منتخب با ضمانت اصالت و خدمات گجتینو", color = Color.White.copy(alpha = .88f), fontSize = 11.sp)
                    Spacer(Modifier.height(10.dp))
                    Text("مشاهده فروشگاه  ←", color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.clickable { onOpenProduct(SITE) })
                }
                Icon(Icons.Default.VerifiedUser, null, tint = Color.White, modifier = Modifier.size(48.dp))
            }
        }
        if (!pushEnabled) item {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp).clip(RoundedCornerShape(14.dp)).background(Color(0xFFE8F5FF)).clickable { onEnablePush() }.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.NotificationsActive, null, tint = Blue)
                Spacer(Modifier.width(8.dp))
                Text("از تخفیف‌ها و محصولات جدید باخبر شو", color = Color(0xFF174A83), fontSize = 12.sp, modifier = Modifier.weight(1f))
                Text("فعال‌سازی", color = Blue, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
        }
        if (categories.isNotEmpty()) item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("دسته‌بندی‌ها", modifier = Modifier.padding(horizontal = 16.dp), fontWeight = FontWeight.Bold, color = Ink)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    androidx.compose.foundation.lazy.LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        item { FilterChip(selected = selectedCategory == null, onClick = { onCategory(null) }, label = { Text("همه") }) }
                        items(categories) { c -> FilterChip(selected = selectedCategory == c.id, onClick = { onCategory(c.id) }, label = { Text(c.name) }) }
                    }
                }
            }
        }
        item { Text(if (query.isNotBlank()) "نتایج جست‌وجو" else "محصولات فروشگاه", modifier = Modifier.padding(horizontal = 16.dp), fontWeight = FontWeight.Bold, color = Ink) }
        if (loading) item { Box(Modifier.fillMaxWidth().padding(30.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Blue) } }
        else if (error.isNotBlank()) item {
            Column(Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.CloudOff, null, tint = Muted, modifier = Modifier.size(38.dp))
                Text(error, color = Muted, fontSize = 12.sp)
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = onRetry) { Text("تلاش دوباره") }
            }
        } else if (products.isEmpty()) item { Text("محصولی پیدا نشد.", modifier = Modifier.padding(20.dp), color = Muted) }
        else item {
            LazyVerticalGrid(columns = GridCells.Fixed(2), modifier = Modifier.fillMaxWidth().height((((products.size + 1) / 2) * 260).dp), contentPadding = PaddingValues(horizontal = 14.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp), userScrollEnabled = false) {
                items(products) { p -> ProductCard(p, p.id in favorites, { onFavorite(p.id) }, { onOpenProduct(p.url) }) }
            }
        }
    }
}

@Composable
private fun ProductCard(product: StoreProduct, favorite: Boolean, onFavorite: () -> Unit, onOpen: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth().clickable(onClick = onOpen), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Surface), elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)) {
        Column(Modifier.padding(10.dp)) {
            Box(Modifier.fillMaxWidth().height(130.dp).clip(RoundedCornerShape(13.dp)).background(Color(0xFFF2F5FA))) {
                if (product.image.isNotBlank()) AsyncImage(model = product.image, contentDescription = product.name, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
                else Icon(Icons.Default.Devices, null, tint = Muted, modifier = Modifier.align(Alignment.Center).size(44.dp))
                IconButton(onClick = onFavorite, modifier = Modifier.align(Alignment.TopEnd).size(34.dp).padding(3.dp).background(Color.White.copy(alpha = .94f), CircleShape)) {
                    Icon(if (favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null, tint = if (favorite) Color(0xFFE74765) else Muted, modifier = Modifier.size(18.dp))
                }
            }
            Spacer(Modifier.height(8.dp))
            Text(product.name, color = Ink, fontSize = 12.sp, fontWeight = FontWeight.Medium, maxLines = 2, minLines = 2, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(6.dp))
            val isDiscount = product.regularPrice.isNotBlank() && product.regularPrice != product.price
            if (isDiscount) Text(formatPrice(product.regularPrice), color = Muted, fontSize = 10.sp, textDecoration = androidx.compose.ui.text.style.TextDecoration.LineThrough)
            Text(if (product.price.isBlank() || product.price == "0") "استعلام قیمت" else formatPrice(product.price), color = Blue, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Spacer(Modifier.height(5.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("مشاهده محصول", color = Muted, fontSize = 10.sp, modifier = Modifier.weight(1f))
                Icon(Icons.Default.ArrowBackIosNew, null, tint = Blue, modifier = Modifier.size(12.dp))
            }
        }
    }
}

@Composable
private fun FavoritesScreen(modifier: Modifier, products: List<StoreProduct>, favorites: Set<Int>, onFavorite: (Int) -> Unit, onOpen: (String) -> Unit) {
    Column(modifier.fillMaxSize().padding(16.dp)) {
        Text("علاقه‌مندی‌های من", fontSize = 21.sp, fontWeight = FontWeight.Bold, color = Ink)
        Spacer(Modifier.height(12.dp))
        if (favorites.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Column(horizontalAlignment = Alignment.CenterHorizontally) { Icon(Icons.Default.FavoriteBorder, null, tint = Muted, modifier = Modifier.size(48.dp)); Text("هنوز محصولی ذخیره نکرده‌ای.", color = Muted) } }
        } else if (products.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("برای نمایش علاقه‌مندی‌ها، اتصال فروشگاه را بررسی کن.", color = Muted) }
        } else {
            LazyVerticalGrid(columns = GridCells.Fixed(2), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(products) { ProductCard(it, true, { onFavorite(it.id) }, { onOpen(it.url) }) }
            }
        }
    }
}

@Composable
private fun TrackingScreen(modifier: Modifier) {
    var order by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var result by remember { mutableStateOf<OrderInfo?>(null) }
    val scope = rememberCoroutineScope()
    Column(modifier.fillMaxSize().padding(18.dp)) {
        Text("پیگیری سفارش", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Ink)
        Text("برای مشاهده وضعیت سفارش، شماره سفارش و ایمیل ثبت‌شده هنگام خرید را وارد کن.", color = Muted, fontSize = 12.sp)
        Spacer(Modifier.height(18.dp))
        Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Surface)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(value = order, onValueChange = { order = it.filter(Char::isDigit); result = null }, modifier = Modifier.fillMaxWidth(), label = { Text("شماره سفارش") }, leadingIcon = { Icon(Icons.Default.ReceiptLong, null) }, singleLine = true)
                OutlinedTextField(value = email, onValueChange = { email = it.trim(); result = null }, modifier = Modifier.fillMaxWidth(), label = { Text("ایمیل ثبت‌شده در سفارش") }, leadingIcon = { Icon(Icons.Default.Email, null) }, singleLine = true)
                Button(onClick = {
                    error = ""; result = null
                    if (order.isBlank() || !email.contains("@")) { error = "شماره سفارش و ایمیل معتبر را وارد کن."; return@Button }
                    loading = true
                    scope.launch { try { result = StoreApi.trackOrder(order, email) } catch (e: Exception) { error = e.message ?: "پیگیری سفارش انجام نشد." } finally { loading = false } }
                }, modifier = Modifier.fillMaxWidth(), enabled = !loading, shape = RoundedCornerShape(14.dp)) {
                    if (loading) CircularProgressIndicator(Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp) else Icon(Icons.Default.Search, null)
                    Spacer(Modifier.width(8.dp)); Text("بررسی وضعیت سفارش")
                }
                if (error.isNotBlank()) Text(error, color = Color(0xFFC0394B), fontSize = 12.sp)
            }
        }
        result?.let { info ->
            Spacer(Modifier.height(14.dp))
            Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Surface)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("سفارش شماره ${info.number}", color = Ink, fontWeight = FontWeight.Bold)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("وضعیت", color = Muted); Text(info.status, color = Blue, fontWeight = FontWeight.Bold) }
                    if (info.date.isNotBlank()) Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("تاریخ", color = Muted); Text(info.date, color = Ink) }
                    if (info.total.isNotBlank()) Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("مبلغ", color = Muted); Text(info.total, color = Ink, fontWeight = FontWeight.Bold) }
                    if (info.items.isNotEmpty()) { Divider(); Text("اقلام سفارش", fontWeight = FontWeight.Bold); info.items.forEach { Text("• $it", color = Muted, fontSize = 12.sp) } }
                    if (info.tracking.isNotBlank()) { Divider(); Text("کد رهگیری: ${info.tracking}", color = Blue, fontWeight = FontWeight.Bold) }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Text("نکته: پیگیری سفارش پس از نصب افزونه همراه اپ روی سایت فعال می‌شود.", color = Muted, fontSize = 11.sp)
    }
}

@Composable
private fun AccountScreen(modifier: Modifier, pushEnabled: Boolean, message: String, onEnablePush: () -> Unit, onDisablePush: () -> Unit, onOpenSite: () -> Unit) {
    Column(modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("حساب من", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Ink)
        Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Navy)) {
            Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Person, null, tint = Color.White, modifier = Modifier.size(42.dp))
                Spacer(Modifier.width(12.dp))
                Column { Text("به خانواده گجتینو خوش آمدی", color = Color.White, fontWeight = FontWeight.Bold); Text("خرید مطمئن لوازم دیجیتال", color = Color(0xFFBBD5FF), fontSize = 12.sp) }
            }
        }
        Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Surface)) {
            Row(Modifier.fillMaxWidth().clickable { onEnablePush() }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.NotificationsActive, null, tint = Blue)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) { Text("اعلان تخفیف‌ها و محصولات جدید", color = Ink, fontWeight = FontWeight.SemiBold); Text(if (pushEnabled) "اعلان‌ها فعال هستند" else "برای فعال‌سازی لمس کن", color = Muted, fontSize = 11.sp) }
                Switch(checked = pushEnabled, onCheckedChange = { if (it) onEnablePush() else onDisablePush() })
            }
        }
        if (message.isNotBlank()) Text(message, color = Muted, fontSize = 12.sp)
        Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Surface)) {
            Row(Modifier.fillMaxWidth().clickable(onClick = onOpenSite).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Language, null, tint = Blue); Spacer(Modifier.width(12.dp)); Text("ورود به وب‌سایت گجتینو", color = Ink, modifier = Modifier.weight(1f)); Icon(Icons.Default.OpenInNew, null, tint = Muted)
            }
        }
        Text("نسخه 1.0.0", color = Muted, fontSize = 11.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
    }
}

private fun formatPrice(raw: String): String {
    val n = raw.toLongOrNull() ?: return raw
    val formatted = DecimalFormat("#,###").format(n)
    return "$formatted تومان"
}

private fun loadFavorites(context: Context): Set<Int> = context.getSharedPreferences("gajetino", Context.MODE_PRIVATE).getStringSet("favorites", emptySet())?.mapNotNull { it.toIntOrNull() }?.toSet() ?: emptySet()
private fun toggleFavorite(context: Context, current: Set<Int>, id: Int): Set<Int> {
    val updated = if (id in current) current - id else current + id
    context.getSharedPreferences("gajetino", Context.MODE_PRIVATE).edit().putStringSet("favorites", updated.map { it.toString() }.toSet()).apply()
    return updated
}
private fun openUrl(context: Context, url: String) { try { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (_: Exception) { } }

private fun enablePromotions(context: Context, onResult: (String) -> Unit) {
    val appId = BuildConfig.FIREBASE_APP_ID
    val apiKey = BuildConfig.FIREBASE_API_KEY
    val projectId = BuildConfig.FIREBASE_PROJECT_ID
    val senderId = BuildConfig.FIREBASE_SENDER_ID
    if (listOf(appId, apiKey, projectId, senderId).any { it.isBlank() }) {
        onResult("برای فعال‌سازی اعلان‌ها ابتدا اطلاعات Firebase را در فایل local.properties وارد کن. راهنما در README است.")
        return
    }
    try {
        val app = FirebaseApp.getApps(context).firstOrNull { it.name == FirebaseApp.DEFAULT_APP_NAME } ?: FirebaseApp.initializeApp(
            context,
            FirebaseOptions.Builder().setApplicationId(appId).setApiKey(apiKey).setProjectId(projectId).setGcmSenderId(senderId).build()
        )
        FirebaseMessaging.getInstance(app).subscribeToTopic("promotions").addOnCompleteListener { task ->
            if (task.isSuccessful) {
                context.getSharedPreferences("gajetino", Context.MODE_PRIVATE).edit().putBoolean("push", true).apply()
                onResult("فعال شد؛ از این پس اعلان‌های تخفیف و محصولات جدید را دریافت می‌کنی.")
            } else onResult("اتصال به سرویس اعلان انجام نشد. تنظیمات Firebase را بررسی کن.")
        }
    } catch (e: Exception) { onResult("فعال‌سازی اعلان انجام نشد: ${e.localizedMessage ?: "خطای Firebase"}") }
}

private fun disablePromotions(context: Context): String {
    try {
        val app = FirebaseApp.getApps(context).firstOrNull { it.name == FirebaseApp.DEFAULT_APP_NAME }
        if (app != null) FirebaseMessaging.getInstance(app).unsubscribeFromTopic("promotions")
    } catch (_: Exception) { }
    context.getSharedPreferences("gajetino", Context.MODE_PRIVATE).edit().putBoolean("push", false).apply()
    return "اعلان‌ها غیرفعال شدند."
}
