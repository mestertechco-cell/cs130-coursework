<?php
/**
 * Plugin Name: Gajetino Mobile App API
 * Description: Order tracking endpoint and Firebase Cloud Messaging alerts for the Gajetino Android app.
 * Version: 1.0.0
 * Author: Gajetino
 */

if (!defined('ABSPATH')) { exit; }

add_action('rest_api_init', function () {
    register_rest_route('gajetino/v1', '/track-order', [
        'methods' => 'POST',
        'callback' => 'gajetino_mobile_track_order',
        'permission_callback' => '__return_true',
        'args' => [
            'order_number' => ['required' => true, 'type' => 'string'],
            'billing_email' => ['required' => true, 'type' => 'string'],
        ],
    ]);
});

function gajetino_mobile_track_order(WP_REST_Request $request) {
    if (!function_exists('wc_get_order')) {
        return new WP_Error('woocommerce_missing', 'سرویس فروشگاه در دسترس نیست.', ['status' => 503]);
    }

    $order_number = sanitize_text_field($request->get_param('order_number'));
    $email = sanitize_email($request->get_param('billing_email'));
    if (!$order_number || !is_email($email)) {
        return new WP_Error('invalid_input', 'شماره سفارش و ایمیل معتبر وارد کنید.', ['status' => 400]);
    }

    // Basic per-IP throttling to make order-number/email guessing harder.
    $client_ip = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : 'unknown';
    $rate_key = 'gajetino_track_' . hash('sha256', $client_ip);
    $attempts = (int) get_transient($rate_key);
    if ($attempts >= 15) {
        return new WP_Error('rate_limited', 'تعداد درخواست‌ها زیاد است. چند دقیقه دیگر دوباره تلاش کنید.', ['status' => 429]);
    }
    set_transient($rate_key, $attempts + 1, 15 * MINUTE_IN_SECONDS);

    // Default WooCommerce order number is the order ID. The meta lookup also
    // supports common custom order-number plugins.
    $order = wc_get_order(absint($order_number));
    if (!$order) {
        $matches = wc_get_orders([
            'limit' => 1,
            'return' => 'objects',
            'meta_query' => [[
                'key' => '_order_number',
                'value' => $order_number,
                'compare' => '=',
            ]],
        ]);
        $order = !empty($matches) ? $matches[0] : false;
    }

    if (!$order || strtolower($order->get_billing_email()) !== strtolower($email)) {
        // Same response for unknown order and mismatched email to avoid leaking order existence.
        return new WP_Error('order_not_found', 'سفارشی با این مشخصات پیدا نشد. شماره سفارش و ایمیل را بررسی کنید.', ['status' => 404]);
    }

    $status = $order->get_status();
    $labels = [
        'pending' => 'در انتظار پرداخت',
        'processing' => 'در حال آماده‌سازی',
        'on-hold' => 'در انتظار بررسی',
        'completed' => 'تکمیل و ارسال‌شده',
        'cancelled' => 'لغوشده',
        'refunded' => 'مستردشده',
        'failed' => 'پرداخت ناموفق',
    ];

    $items = [];
    foreach ($order->get_items() as $item) {
        $items[] = $item->get_name() . ' × ' . $item->get_quantity();
    }

    $tracking = '';
    $tracking_items = $order->get_meta('_wc_shipment_tracking_items', true);
    if (is_array($tracking_items) && !empty($tracking_items)) {
        $first = reset($tracking_items);
        if (is_array($first)) {
            $tracking = trim(($first['tracking_provider'] ?? '') . ' ' . ($first['tracking_number'] ?? ''));
        }
    }
    if (!$tracking) {
        $tracking = (string) $order->get_meta('_tracking_number', true);
    }

    return rest_ensure_response([
        'number' => $order->get_order_number(),
        'status' => $status,
        'status_label' => $labels[$status] ?? wc_get_order_status_name('wc-' . $status),
        'total' => wp_strip_all_tags(wc_price($order->get_total(), ['currency' => $order->get_currency()])),
        'date' => $order->get_date_created() ? $order->get_date_created()->date_i18n('Y/m/d') : '',
        'items' => $items,
        'tracking' => $tracking,
    ]);
}

/** Firebase HTTP v1 helpers. Keep the service-account JSON outside the public web root. */
function gajetino_b64url($value) {
    return rtrim(strtr(base64_encode($value), '+/', '-_'), '=');
}

function gajetino_firebase_access_token() {
    $cached = get_transient('gajetino_fcm_access_token');
    if ($cached) return $cached;

    if (!defined('GAJETINO_FIREBASE_SERVICE_ACCOUNT') || !is_readable(GAJETINO_FIREBASE_SERVICE_ACCOUNT)) {
        return new WP_Error('firebase_credentials_missing', 'Firebase service account file is not configured.');
    }
    $service = json_decode(file_get_contents(GAJETINO_FIREBASE_SERVICE_ACCOUNT), true);
    if (empty($service['client_email']) || empty($service['private_key']) || empty($service['project_id'])) {
        return new WP_Error('firebase_credentials_invalid', 'Firebase service account JSON is invalid.');
    }

    $now = time();
    $header = gajetino_b64url(wp_json_encode(['alg' => 'RS256', 'typ' => 'JWT']));
    $claims = gajetino_b64url(wp_json_encode([
        'iss' => $service['client_email'],
        'scope' => 'https://www.googleapis.com/auth/firebase.messaging',
        'aud' => 'https://oauth2.googleapis.com/token',
        'iat' => $now,
        'exp' => $now + 3500,
    ]));
    $unsigned = $header . '.' . $claims;
    $signature = '';
    if (!openssl_sign($unsigned, $signature, $service['private_key'], OPENSSL_ALGO_SHA256)) {
        return new WP_Error('firebase_sign_failed', 'Could not sign Firebase JWT.');
    }
    $jwt = $unsigned . '.' . gajetino_b64url($signature);
    $response = wp_remote_post('https://oauth2.googleapis.com/token', [
        'timeout' => 15,
        'headers' => ['Content-Type' => 'application/x-www-form-urlencoded'],
        'body' => [
            'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
            'assertion' => $jwt,
        ],
    ]);
    if (is_wp_error($response)) return $response;
    $body = json_decode(wp_remote_retrieve_body($response), true);
    if (empty($body['access_token'])) return new WP_Error('firebase_token_failed', 'Firebase OAuth token request failed.');
    set_transient('gajetino_fcm_access_token', $body['access_token'], 3300);
    return $body['access_token'];
}

function gajetino_send_promotion($title, $body, $url = '') {
    if (!defined('GAJETINO_FIREBASE_SERVICE_ACCOUNT') || !is_readable(GAJETINO_FIREBASE_SERVICE_ACCOUNT)) {
        error_log('[Gajetino App] Firebase service account is not configured; push was skipped.');
        return false;
    }
    $service = json_decode(file_get_contents(GAJETINO_FIREBASE_SERVICE_ACCOUNT), true);
    $token = gajetino_firebase_access_token();
    if (is_wp_error($token)) {
        error_log('[Gajetino App] ' . $token->get_error_message());
        return false;
    }
    $project = rawurlencode($service['project_id']);
    $payload = [
        'message' => [
            'topic' => 'promotions',
            'notification' => ['title' => wp_strip_all_tags($title), 'body' => wp_strip_all_tags($body)],
            'data' => ['title' => wp_strip_all_tags($title), 'body' => wp_strip_all_tags($body), 'url' => esc_url_raw($url)],
            'android' => ['priority' => 'HIGH', 'notification' => ['channel_id' => 'promotions']],
        ],
    ];
    $response = wp_remote_post('https://fcm.googleapis.com/v1/projects/' . $project . '/messages:send', [
        'timeout' => 15,
        'headers' => ['Authorization' => 'Bearer ' . $token, 'Content-Type' => 'application/json'],
        'body' => wp_json_encode($payload),
    ]);
    if (is_wp_error($response) || wp_remote_retrieve_response_code($response) >= 300) {
        error_log('[Gajetino App] FCM send failed: ' . (is_wp_error($response) ? $response->get_error_message() : wp_remote_retrieve_body($response)));
        return false;
    }
    return true;
}

// Notify subscribers when a product is first published.
add_action('transition_post_status', function ($new_status, $old_status, $post) {
    if ($post->post_type !== 'product' || $new_status !== 'publish' || $old_status === 'publish') return;
    if (!function_exists('wc_get_product')) return;
    $product = wc_get_product($post->ID);
    if (!$product) return;
    gajetino_send_promotion('محصول جدید در گجتینو', $product->get_name() . ' به فروشگاه اضافه شد.', get_permalink($post->ID));
}, 20, 3);

// Notify subscribers when a product receives or changes to a valid sale price.
add_action('woocommerce_product_object_updated_props', function ($product, $updated_props) {
    if (!is_array($updated_props) || !in_array('sale_price', $updated_props, true)) return;
    $sale = (float) $product->get_sale_price();
    $regular = (float) $product->get_regular_price();
    if ($sale <= 0 || $regular <= 0 || $sale >= $regular) return;
    gajetino_send_promotion('تخفیف ویژه در گجتینو', $product->get_name() . ' با قیمت ویژه عرضه شد.', get_permalink($product->get_id()));
}, 20, 2);
