# اپلیکیشن اندروید گجتینو

پروژه‌ی اولیه‌ی اپ اختصاصی فروشگاه [gajetino.com](https://www.gajetino.com) با Kotlin و Jetpack Compose.

## امکانات پیاده‌سازی‌شده در سورس

- رابط فارسی و راست‌چین با صفحه‌ی شروع و آیکون اختصاصی
- دریافت زنده‌ی محصولات، قیمت‌ها، تصاویر و دسته‌بندی‌ها از WooCommerce Store API
- جست‌وجوی محصول و فیلتر دسته‌بندی
- علاقه‌مندی‌های محلی روی دستگاه
- بازکردن صفحه‌ی محصول و پرداخت امن از طریق وب‌سایت
- صفحه‌ی پیگیری سفارش با شماره سفارش و ایمیل صورتحساب
- زیرساخت Firebase Cloud Messaging برای اعلان محصول جدید و تخفیف

## پیش‌نیازها

- Android Studio جدید
- JDK 17
- Android SDK Platform 35
- دسترسی فروشگاه به WooCommerce Store API

## بازکردن پروژه و ساخت APK

1. فایل ZIP را استخراج کن.
2. پوشه‌ی `gajetino-android` را در Android Studio باز کن.
3. اجازه بده Gradle Sync انجام شود و Android SDK 35 نصب باشد.
4. از منوی **Build → Build Bundle(s) / APK(s) → Build APK(s)** خروجی بگیر.
5. فایل APK در مسیر `app/build/outputs/apk/debug/app-debug.apk` ساخته می‌شود.

> در محیط ساخت فعلی Android SDK و Gradle نصب نیست؛ بنابراین APK در این مرحله کامپایل و تست دستگاهی نشده است. سورس پروژه و فایل‌های سمت وردپرس آماده شده‌اند، اما برای APK نهایی باید پروژه در Android Studio ساخته شود.

## اتصال فروشگاه

اپ از این مسیرهای عمومی WooCommerce استفاده می‌کند:

- `https://www.gajetino.com/wp-json/wc/store/v1/products`
- `https://www.gajetino.com/wp-json/wc/store/v1/products/categories`

اگر افزونه‌ی امنیتی یا تنظیمات سرور REST API را مسدود کرده باشد، باید دسترسی عمومی Store API برای محصولات و دسته‌بندی‌ها فعال شود. کلیدهای محرمانه‌ی WooCommerce داخل اپ قرار داده نمی‌شوند.

## فعال‌سازی پیگیری سفارش

1. در پیشخوان وردپرس به **افزونه‌ها → افزودن افزونه تازه → بارگذاری افزونه** برو.
2. فایل `wordpress-plugin/gajetino-mobile-api.zip` را بارگذاری و فعال کن.
3. اپ از endpoint زیر استفاده می‌کند:
   `POST https://www.gajetino.com/wp-json/gajetino/v1/track-order`
4. کاربر باید شماره سفارش و ایمیل صورتحساب همان سفارش را وارد کند. سرور فقط پس از تطبیق ایمیل، اطلاعات سفارش را برمی‌گرداند.
5. اگر سایت از افزونه‌ی شماره سفارش سفارشی یا افزونه‌ی رهگیری مرسوله استفاده می‌کند، ممکن است لازم باشد کلید متای آن افزونه در فایل PHP به بخش tracking اضافه شود.

## فعال‌سازی اعلان تخفیف و محصول جدید

اعلان‌ها با Firebase Cloud Messaging و Topic به نام `promotions` کار می‌کنند.

### بخش Firebase

1. در Firebase Console یک پروژه بساز.
2. یک Android App با Package Name دقیق `com.gajetino.app` ثبت کن.
3. مقادیر App ID، API Key، Project ID و Sender ID را دریافت کن.
4. فایل `local.properties` را Android Studio معمولاً برای مسیر SDK می‌سازد؛ چهار مقدار Firebase را از `local.properties.example` به همان فایل موجود اضافه کن (مقادیر `sdk.dir` را پاک نکن). این فایل را منتشر یا برای دیگران ارسال نکن.
5. پروژه را دوباره در Android Studio Sync و APK جدید بساز.
6. در Firebase، سرویس **Firebase Cloud Messaging API (HTTP v1)** را فعال کن.
7. یک Service Account با دسترسی Firebase Cloud Messaging Admin بساز و فایل JSON آن را دانلود کن.

### بخش وردپرس

1. فایل Service Account را خارج از پوشه‌ی عمومی وب‌سایت نگه دار.
2. مسیر کامل فایل را در `wp-config.php` اضافه کن:

```php
define('GAJETINO_FIREBASE_SERVICE_ACCOUNT', '/absolute/private/path/firebase-service-account.json');
```

3. افزونه‌ی `Gajetino Mobile App API` را فعال نگه دار.
4. پس از آن، انتشار محصول جدید و ثبت/تغییر قیمت فروش محصول (sale price) اعلان Topic را ارسال می‌کند.

**نکته امنیتی:** فایل Service Account فقط روی سرور بماند؛ هرگز آن را داخل APK، مخزن عمومی یا پوشه‌ی قابل دانلود سایت قرار نده.

## نکات و محدودیت‌های نسخه اول

- خرید و پرداخت نهایی در صفحه‌ی امن وب‌سایت انجام می‌شود تا درگاه پرداخت فعلی و قوانین سفارش سایت حفظ شوند.
- صفحه‌ی پیگیری سفارش به افزونه‌ی PHP داخل پوشه‌ی `wordpress-plugin` وابسته است.
- اعلان‌ها تا زمانی که Firebase و کلید سرور تنظیم نشده باشند، فعال نمی‌شوند.
- قبل از انتشار عمومی، لازم است روی گوشی واقعی تست شود و سیاست حریم خصوصی/مجوز اعلان‌ها و تنظیمات امضای Release تکمیل شوند.

## ساختار فایل‌ها

- `app/` کد اپلیکیشن Kotlin و رابط Compose
- `app/src/main/res/drawable-nodpi/gajetino_logo.png` لوگوی اپ
- `wordpress-plugin/` افزونه‌ی API وردپرس
- `local.properties.example` الگوی تنظیم Firebase
